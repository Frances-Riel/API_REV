<?php

namespace App\Http\Controllers;

use App\Models\Book;
use Illuminate\Http\Request;

class BookController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $books = Book::all();
        return response($books);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $this ->validate($request, [
            "title"=> "required",
            "author"=> "required",
            "published_at" => "required|date"]);

            $book = Book::create($request->all());
            return response($book, 201);
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $book = Book::find($id);
        return response($book);
    }
    public function byTitle($title)
    {
        $title = Book::where('title',$title)->get();
        return response($title);
    }
    public function byAuthor($author)
    {
        $author = Book::where('author',$author)->get();
        return response($author);
    }
    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $this ->validate($request, [
            "title"=> "required",
            "author"=> "required",
            "published_at" => "required|data"]);
            $book = Book::findOrFail($id);
            $book -> update($request->all());

            return response($book, 200);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $book = Book::findOrFail($id);
        if($book != null) {
            $book->delete();
            return response (["message"=>"successfully deleted","success"=>"true"], 200);
        } else {
            return response (["message"=>"record not found","success"=>"false"]);

        }
    }
}
